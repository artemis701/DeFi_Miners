import { useState, useEffect } from 'react';

const AstroBank = () => {
	return (
		<div className='text-white text-6xl mx-auto flex justify-center items-center h-screen'>
			Astro Bank
		</div>
	);
};

export default AstroBank;
