const api = {
    rootUrl: window.location.origin,
    baseUrl: 'http://localhost:5000/api', //mock data base folder
    imgUrl: "http://localhost:5000/uploads/",
    cova_api_key: 'ckey_7b7a61bcb3bd4a5ebf594acf085'
}

export default api;